# Grailed Watch

A scrollable feed of new Grailed listings across your curated brand list, filtered to your sizes — no notifications, just a page you check whenever you want.

Runs on a schedule for free using GitHub Actions, and the feed lives at a URL you can bookmark to your phone's home screen.

## How it works
- `scraper/grailed_scraper.py` checks Grailed for each brand in `scraper/brands.json`, filters to your sizes, and writes results to `docs/listings.json`
- `.github/workflows/scrape.yml` runs that script automatically every 4 hours (editable)
- `docs/index.html` is the feed page — reads `listings.json` and renders it as a scrollable list
- GitHub Pages serves `docs/` as a live website
- Listings older than 14 days drop out of the feed automatically

Nothing pings you. You open the page, scroll, close it.

## One-time setup (~10 minutes)

**1. Create a GitHub account** if you don't have one — [github.com](https://github.com), free.

**2. Create a new repository**
   - Click "+" → "New repository" → name it (e.g. `grailed-watch`) → Public or Private (either works) → Create.

**3. Upload these files**
   - On the repo page, click "Add file" → "Upload files"
   - Drag in this entire folder's contents, keeping the structure:
     ```
     .github/workflows/scrape.yml
     docs/index.html
     docs/listings.json
     scraper/grailed_scraper.py
     scraper/brands.json
     ```
   - Commit the upload.

**4. Set your sizes**
   - In GitHub, open `scraper/grailed_scraper.py`, click the pencil (edit) icon
   - Find `MY_SIZES = ["M", "32"]` near the top and change it to your actual sizes
   - Commit directly to the main branch

**5. Enable GitHub Pages**
   - Repo → Settings → Pages
   - Under "Build and deployment" → Source: "Deploy from a branch"
   - Branch: `main`, folder: `/docs` → Save
   - GitHub will give you a URL like `https://yourusername.github.io/grailed-watch/` — that's your feed

**6. Enable Actions** (usually on by default for new repos)
   - Repo → Actions tab → if prompted, click "I understand my workflows, enable them"

**7. Run it once manually to test**
   - Actions tab → "Scrape Grailed Feed" (left sidebar) → "Run workflow" button → Run workflow
   - Takes ~8–10 minutes for the first full pass across ~338 brands
   - Refresh your Pages URL after it finishes — you should see listings (or an empty state if nothing matched yet)

**8. Bookmark it to your phone**
   - Open the Pages URL on your phone
   - iOS Safari: Share → "Add to Home Screen"
   - Android Chrome: ⋮ menu → "Add to Home screen"
   - Now it opens like an app, full screen, no browser chrome

From here it's fully hands-off — the workflow runs every 4 hours on its own, and the feed just fills in over time.

## Adjusting things later
- **Scrape frequency:** edit the `cron` line in `.github/workflows/scrape.yml` (all times UTC)
- **Sizes:** edit `MY_SIZES` in `scraper/grailed_scraper.py`
- **Brand list:** edit `scraper/brands.json` directly, or add/remove brands anytime
- **How long listings stay in the feed:** `PRUNE_AFTER_DAYS` in the scraper (default 14)

## If the feed stays empty after a real run
Grailed's page markup changes periodically. Open a Grailed search page in your own browser, right-click a listing card → Inspect, and update the `SELECTORS` dict near the top of `grailed_scraper.py` to match the current class names, then commit the change — the next scheduled run will pick it up.

## About the location (US/Canada) filter
This one comes with a real caveat: Grailed doesn't reliably expose seller ship-from location on search-result cards the same clean way it shows price or size, so the scraper's location detection is the least certain piece of this whole setup — it wasn't verifiable without live access to the site.

To avoid that uncertainty silently hiding your entire feed if the selector's wrong, it's built to fail open:
- Each listing gets tagged `US`, `CA`, `OTHER`, or `UNKNOWN`
- The feed page shows a small tag on every card (next to the size tag) so you can see what it actually detected — tap and hold (or check the title) to see the raw text it found, if any
- The "US & Canada only" toggle on the page hides `OTHER` but keeps `UNKNOWN` visible, since an unverified selector failing shouldn't be treated the same as confirming something's international

If after a real run you see the location tag is always `?` (unknown), the selector needs adjusting — same process as above: inspect a Grailed listing card in your browser, find whatever element shows seller location (if any), and update `SELECTORS["location"]` in `grailed_scraper.py`.

## A note on Terms of Service
Scraping Grailed's public pages isn't hacking or malware, but it does technically go against their ToS. This is built for personal, low-volume use — the delays in the script and the 4-hour schedule are there on purpose. Don't crank up the frequency or share the repo publicly with your brand/size preferences attached.

## Later phases (not built)
- Craigslist — much easier to scrape (plain HTML, no JS rendering needed)
- Facebook Marketplace — hardest of the three (login walls, anti-bot measures)
